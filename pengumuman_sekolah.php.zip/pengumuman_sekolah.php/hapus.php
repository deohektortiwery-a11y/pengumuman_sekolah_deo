<?php
include 'koneksi.php';

if (
    $_SERVER['REQUEST_METHOD'] !== 'POST' ||
    !isset($_POST['id']) ||
    !ctype_digit($_POST['id']) ||
    (int) $_POST['id'] < 1
) {
    header("Location: index.php");
    exit;
}

$id = (int) $_POST['id'];

$stmt = mysqli_prepare(
    $koneksi,
    "DELETE FROM pengumuman_sekolah WHERE id_pengumuman = ?"
);

if (!$stmt) {
    die("Gagal menyiapkan query penghapusan.");
}

mysqli_stmt_bind_param($stmt, "i", $id);

if (!mysqli_stmt_execute($stmt)) {
    mysqli_stmt_close($stmt);
    die("Gagal menghapus data.");
}

mysqli_stmt_close($stmt);

header("Location: index.php");
exit;
?>