<?php
include 'koneksi.php';

$query = "SELECT id_pengumuman, judul, isi, kategori, tanggal_terbit
          FROM pengumuman_sekolah
          ORDER BY id_pengumuman DESC";

$data = mysqli_query($koneksi, $query);

if (!$data) {
    die("Gagal mengambil data: " . mysqli_error($koneksi));
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Pengumuman Sekolah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2 class="mb-4">Data Pengumuman Sekolah</h2>

    <a href="tambah.php" class="btn btn-success mb-3">
        + Tambah Pengumuman
    </a>

    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Judul</th>
                    <th>Isi Pengumuman</th>
                    <th>Kategori</th>
                    <th>Tanggal Terbit</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (mysqli_num_rows($data) > 0) { ?>
                <?php while ($row = mysqli_fetch_assoc($data)) { ?>
                    <tr>
                        <td><?= (int) $row['id_pengumuman'] ?></td>
                        <td><?= htmlspecialchars($row['judul'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= nl2br(htmlspecialchars($row['isi'], ENT_QUOTES, 'UTF-8')) ?></td>
                        <td><?= htmlspecialchars($row['kategori'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars($row['tanggal_terbit'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td>
                            <a href="edit.php?id=<?= (int) $row['id_pengumuman'] ?>"
                               class="btn btn-warning btn-sm">Edit</a>

                            <form action="hapus.php" method="post" class="d-inline"
                                  onsubmit="return confirm('Yakin ingin menghapus pengumuman ini?')">
                                <input type="hidden" name="id"
                                       value="<?= (int) $row['id_pengumuman'] ?>">
                                <button type="submit" class="btn btn-danger btn-sm">
                                    Hapus
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php } ?>
            <?php } else { ?>
                <tr>
                    <td colspan="6" class="text-center">
                        Belum ada data pengumuman.
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>

<?php mysqli_free_result($data); ?>