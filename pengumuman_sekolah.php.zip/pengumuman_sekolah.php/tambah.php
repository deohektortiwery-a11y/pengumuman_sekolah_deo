<?php
include 'koneksi.php';

$error = '';
$kategoriPilihan = ['Akademik', 'Kegiatan', 'Informasi'];

$judul = '';
$isi = '';
$kategori = '';
$tanggal = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $kategori = $_POST['kategori'] ?? '';
    $tanggal = $_POST['tanggal_terbit'] ?? '';

    $tanggalObj = DateTime::createFromFormat('!Y-m-d', $tanggal);
    $tanggalValid = $tanggalObj &&
        $tanggalObj->format('Y-m-d') === $tanggal;

    if ($judul === '' || $isi === '' || $tanggal === '') {
        $error = 'Semua field wajib diisi.';
    } elseif (mb_strlen($judul) > 100) {
        $error = 'Judul maksimal 100 karakter.';
    } elseif (!in_array($kategori, $kategoriPilihan, true)) {
        $error = 'Silakan pilih kategori yang tersedia.';
    } elseif (!$tanggalValid) {
        $error = 'Tanggal terbit tidak valid.';
    } else {
        $stmt = mysqli_prepare(
            $koneksi,
            "INSERT INTO pengumuman_sekolah
             (judul, isi, kategori, tanggal_terbit)
             VALUES (?, ?, ?, ?)"
        );

        if (!$stmt) {
            $error = 'Gagal menyiapkan query.';
        } else {
            mysqli_stmt_bind_param(
                $stmt, "ssss",
                $judul, $isi, $kategori, $tanggal
            );

            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_close($stmt);
                header("Location: index.php");
                exit;
            }

            $error = 'Gagal menyimpan data: ' . mysqli_stmt_error($stmt);
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Pengumuman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h4 class="mb-0">Tambah Pengumuman</h4>
        </div>

        <div class="card-body">
            <?php if ($error !== '') { ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php } ?>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">Judul</label>
                    <input type="text" name="judul" class="form-control"
                           maxlength="100"
                           value="<?= htmlspecialchars($judul, ENT_QUOTES, 'UTF-8') ?>"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Isi Pengumuman</label>
                    <textarea name="isi" class="form-control" rows="5" required><?= htmlspecialchars($isi, ENT_QUOTES, 'UTF-8') ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kategori</label>
                    <select name="kategori" class="form-select" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php foreach ($kategoriPilihan as $pilihan) { ?>
                            <option value="<?= htmlspecialchars($pilihan, ENT_QUOTES, 'UTF-8') ?>"
                                <?= $kategori === $pilihan ? 'selected' : '' ?>>
                                <?= htmlspecialchars($pilihan, ENT_QUOTES, 'UTF-8') ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tanggal Terbit</label>
                    <input type="date" name="tanggal_terbit"
                           class="form-control"
                           value="<?= htmlspecialchars($tanggal, ENT_QUOTES, 'UTF-8') ?>"
                           required>
                </div>

                <button type="submit" class="btn btn-success">Simpan</button>
                <a href="index.php" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

</body>
</html>