<?php
include 'koneksi.php';

if (
    !isset($_GET['id']) ||
    !ctype_digit($_GET['id']) ||
    (int) $_GET['id'] < 1
) {
    header("Location: index.php");
    exit;
}

$id = (int) $_GET['id'];
$error = '';
$kategoriPilihan = ['Akademik', 'Kegiatan', 'Informasi'];

$stmt = mysqli_prepare(
    $koneksi,
    "SELECT id_pengumuman, judul, isi, kategori, tanggal_terbit
     FROM pengumuman_sekolah
     WHERE id_pengumuman = ?"
);

mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
mysqli_stmt_close($stmt);

if (!$row) {
    exit("Data pengumuman tidak ditemukan.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $judul = trim($_POST['judul'] ?? '');
    $isi = trim($_POST['isi'] ?? '');
    $kategori = $_POST['kategori'] ?? '';
    $tanggal = $_POST['tanggal_terbit'] ?? '';

    $tanggalObj = DateTime::createFromFormat('!Y-m-d', $tanggal);
    $tanggalValid = $tanggalObj &&
        $tanggalObj->format('Y-m-d') === $tanggal;

    if ($judul === '' || $isi === '' || $tanggal === '') {
        $error = 'Semua field wajib diisi.';
    } elseif (mb_strlen($judul) > 100) {
        $error = 'Judul maksimal 100 karakter.';
    } elseif (!in_array($kategori, $kategoriPilihan, true)) {
        $error = 'Kategori tidak valid.';
    } elseif (!$tanggalValid) {
        $error = 'Tanggal terbit tidak valid.';
    } else {
        $stmt = mysqli_prepare(
            $koneksi,
            "UPDATE pengumuman_sekolah
             SET judul = ?, isi = ?, kategori = ?, tanggal_terbit = ?
             WHERE id_pengumuman = ?"
        );

        mysqli_stmt_bind_param(
            $stmt, "ssssi",
            $judul, $isi, $kategori, $tanggal, $id
        );

        if (mysqli_stmt_execute($stmt)) {
            mysqli_stmt_close($stmt);
            header("Location: index.php");
            exit;
        }

        $error = 'Gagal memperbarui data pengumuman.';
        mysqli_stmt_close($stmt);
    }

    $row['judul'] = $judul;
    $row['isi'] = $isi;
    $row['kategori'] = $kategori;
    $row['tanggal_terbit'] = $tanggal;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Pengumuman</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-header bg-warning">
            <h4 class="mb-0">Edit Pengumuman</h4>
        </div>

        <div class="card-body">
            <?php if ($error !== '') { ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?>
                </div>
            <?php } ?>

            <form method="post">
                <div class="mb-3">
                    <label class="form-label">ID Pengumuman</label>
                    <input type="text" class="form-control"
                           value="<?= (int) $row['id_pengumuman'] ?>"
                           disabled>
                </div>

                <div class="mb-3">
                    <label class="form-label">Judul</label>
                    <input type="text" name="judul" class="form-control"
                           maxlength="100"
                           value="<?= htmlspecialchars($row['judul'], ENT_QUOTES, 'UTF-8') ?>"
                           required>
                </div>

                <div class="mb-3">
                    <label class="form-label">Isi Pengumuman</label>
                    <textarea name="isi" class="form-control" rows="5" required><?= htmlspecialchars($row['isi'], ENT_QUOTES, 'UTF-8') ?></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label">Kategori</label>
                    <select name="kategori" class="form-select" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php foreach ($kategoriPilihan as $pilihan) { ?>
                            <option value="<?= htmlspecialchars($pilihan, ENT_QUOTES, 'UTF-8') ?>"
                                <?= $row['kategori'] === $pilihan ? 'selected' : '' ?>>
                                <?= htmlspecialchars($pilihan, ENT_QUOTES, 'UTF-8') ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Tanggal Terbit</label>
                    <input type="date" name="tanggal_terbit"
                           class="form-control"
                           value="<?= htmlspecialchars($row['tanggal_terbit'], ENT_QUOTES, 'UTF-8') ?>"
                           required>
                </div>

                <button type="submit" class="btn btn-warning">Update</button>
                <a href="index.php" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>

</body>
</html>